echo "本配置文件为您提供了大量开发要用到的插件多达150个包括:\n ai补全 lsp 语法高亮 文件图标 文件树等等多达五十多个插件\n注意: 本目录含有一个字体文件含有大量插件所需的特殊字符如有需要请自己切换\n"
echo "注意：配置文件将覆盖原有的 Neovim 配置文件，如有需要请先备份！"
read -p "是否继续？(y/n): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "已取消操作。"
    exit 0
fi
echo -e "正在安装vim-plug...\n如果安装失败请开启网络代理"
curl -fLo ~/.local/share/nvim/site/autoload/plug.vim --create-dirs \
     https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim
echo "正在覆盖配置文件..."
cp init.vim ~/.config/nvim/
echo "安装完成，请打开 Neovim 并运行 :PlugInstall 安装插件。"